<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->post('registration/create', 'UserController::create');
$routes->get('registration/success', 'UserController::success'); // Adjust the controller method as needed





$routes->get('user/all', 'UserController::userAll'); // Route For View All Inserted Users





/* 
Define a Route for the Edit Page:
In your app/Config/Routes.php file, define a route that maps to the UserController::edit method:
*/
$routes->get('user/edit/(:num)', 'UserController::edit/$1');// Route For User Edit Page


//Route for Update Page
$routes->post('user/update/(:num)', 'UserController::update/$1'); // Route For User Update Controller Method

$routes->get('user/updatesuccess', 'UserController::updateSuccess'); // Adjust the controller method as needed

//Route for User View Page
$routes->get('user/view/(:num)', 'UserController::view/$1'); // Adjust the controller method as needed
