<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class UserController extends Controller
{
    public function create()
    {
        $userModel = new UserModel();

        // Validate user input (you should add validation rules)

        /*
        $rules = [
            'username' => 'required',
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]',
        ];

        if (!$this->validate($rules)) {
            $validationErrors = implode('\n', $this->validator->getErrors());
            echo "<script>alert('Validation errors:\\n" . $validationErrors . "');</script>";
            return view('user_registration');
        }
        */

        // Prepare user data
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        ];

        // Insert the user data into the database
        $userModel->insert($data);

        // Redirect to a success page or display a success message
        return redirect()->to('/registration/success'); // Adjust the URL as needed
    }

    //Registration Success Page Method
    public function success()
    {
        return view('registration_success');
    }

    //View All Registered Users Page Method
    public function userAll()
    {
        $userModel = new UserModel();
        $users = $userModel->findAll(); // Fetch all user records

        return view('user_all', ['users' => $users]);
    }






    /* For Edit and Update */
    /* For Edit page */
    /* 
    Create an Edit Method in the Controller:
    In your UserController.php controller, create the edit method to retrieve the user's data by ID and load the user_edit view:
    */
    public function edit($userId)
    {
        $userModel = new UserModel();
        $user = $userModel->find($userId);

        if ($user) {
            return view('user_edit', ['user' => $user]);
        } else {
            // Handle the case when the user does not exist
            return redirect()->to('/user/all'); // Redirect to the user list or show an error message
        }
    }



    /* For Update page */
    /* 
    Create an Update Method in the Controller:
    To handle the form submission for updating the user's data, create an update method in your UserController.php controller:
    */
    public function update($userId)
    {
        $userModel = new UserModel();
        $user = $userModel->find($userId);

        if ($user) 
        {
            // Validate and update user data
            $data = [
                'username' => $this->request->getPost('username'),
                'email' => $this->request->getPost('email'),
                'password' => $this->request->getPost('password'),
            ];

            $userModel->update($userId, $data);

            // Redirect to the user view or a success page
            //return redirect()->to("/user/view/{$userId}");
            return redirect()->to("/user/updatesuccess");
        } 
        else 
        {
            // Handle the case when the user does not exist
            return redirect()->to('/user/all'); // Redirect to the user list or show an error message
        }
    }



    //Registration Success Page Method
    public function updateSuccess()
    {
        return view('registration_update_success');
    }



    public function view($userId)
    {
        $userModel = new UserModel();
        $user = $userModel->find($userId);

        if ($user) {
            return view('user_view', ['user' => $user]);
        } else {
            // Handle the case when the user does not exist
            return redirect()->to('/user/all'); // Redirect to the user list or show an error message
        }
    }

    


}


?>