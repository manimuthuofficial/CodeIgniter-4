<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->post('registration/create', 'UserController::create');
$routes->get('registration/success', 'UserController::success'); // Adjust the controller method as needed

