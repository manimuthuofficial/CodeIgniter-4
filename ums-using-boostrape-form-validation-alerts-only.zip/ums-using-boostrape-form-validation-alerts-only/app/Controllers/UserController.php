<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class UserController extends Controller
{
    public function create()
    {
        $userModel = new UserModel();

        // Validate user input (you should add validation rules)

        /*
        $rules = [
            'username' => 'required',
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]',
        ];

        if (!$this->validate($rules)) {
            $validationErrors = implode('\n', $this->validator->getErrors());
            echo "<script>alert('Validation errors:\\n" . $validationErrors . "');</script>";
            return view('user_registration');
        }
        */

        // Prepare user data
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        ];

        // Insert the user data into the database
        $userModel->insert($data);

        // Redirect to a success page or display a success message
        return redirect()->to('/registration/success'); // Adjust the URL as needed
    }

    public function success()
    {
        return view('registration_success');
    }



}


?>