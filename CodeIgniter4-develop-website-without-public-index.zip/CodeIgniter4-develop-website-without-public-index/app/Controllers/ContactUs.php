<?php

// Contact.php
namespace App\Controllers;

use CodeIgniter\Controller;

class ContactUs extends Controller
{
    public function index()
    {
        return view('contact-us');
    }
}




?>