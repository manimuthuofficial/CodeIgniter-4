<?php

// About.php
namespace App\Controllers;

use CodeIgniter\Controller;

class AboutUs extends Controller
{
    public function index()
    {
        return view('about-us');
    }
}




?>