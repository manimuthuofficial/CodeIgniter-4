<!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="<?= base_url('/') ?>">CodeIgniter4</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="public/assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="active" href="<?= base_url('/') ?>">Home</a></li>
          <li><a href="<?= base_url('/about-us') ?>">About</a></li>          
          <li><a href="<?= base_url('/contact-us') ?>">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <a href="<?= base_url('/contact-us') ?>" class="get-started-btn">Get Started</a>

    </div>
  </header><!-- End Header -->